function myFunction() {
    document.getElementById('demo').innerHTML = '哈哈哈哈'
}