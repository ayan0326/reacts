import React, { useEffect } from "react";

export default function AuditPage() {
  useEffect(() => {
    getDomname();
  }, []);

  // A.点击的时候触发事件-弹窗
  const myfun1 = () => {
    alert("hello word");
  };

  const myfun2 = () => {
    alert("hahahahahahaha");
  };

  const onLoad = () => {
    let test = document.getElementById("test");
    test.addEventListener("click", myfun2);
    test.addEventListener("click", myfun1);
  };

  // B.对象定义
  let obj = {}; // 打印结果继承了Object各种方法和属性
  let obj1 = Object.create(null); // 什么都没有
  // console.log(obj, '----', obj1);;;;;

  // C.this指向   apply, call, bind

  // D、判断：1、if / if else / if elseif
  //      2、三元表达式
  //      3、switch
  const number = 12;
  if (number > 5) {
    // alert('成立')
  }

  const number1 = 5;
  if (number1 > 9) {
    console.log(5);
  } else {
    console.log(9);
  }

  const number2 = 6;
  number2 > 5 ? console.log(6) : console.log(0);

  switch (number2) {
    case number2 < 8:
      return console.log("hahhahahah");
    case number2 > 3:
      return console.log("-----");
    default:
      break;
  }

  //E、循环语句 for , 初始化变量i=1,每次循环加一，i不能大于10，，即小于等于10为止结束
  // for(var i=1; i<=10; i++) {
  //   console.log('----',i)
  // }

  // for(var i=1; i<=10; i++) {
  //   console.log('----',i)
  //   for(var l=1; l<=3; l++) {
  //     console.log('l',l)
  //   }
  // }

  // 循环语句 while
  var age = 0;
  while (age <= 20) {
    age++;
    // console.log(age);
  }

  const arr = new Array();
  console.log(arr);

  // F、函数
  const fun1 = (aa, bb) => {
    // aa bb 两个行参
    console.log("arguments", arguments);
    return aa + bb;
  };
  // 调用函数是传入实参
  // console.log(fun1(5, 9));

  // arguments 是当前函数的一个内置对象，存储了传递的所有实参

  // 函数的声明方式   自定义或者匿名

  // G、作用域

  // H、对象
  // console.log(Math.PI)  rondom   Date()
  // var now = new Date();
  // console.log(now)

  // I、DOM
  // DOM获取页面元素
  const getDomname = () => {
    const newName = document.getElementById("name");
    console.log(newName);
  };

  const onClick = () => {
    // 事件源    新名字标签
    // 事件类型  点击
    // 事件处理程序   函数-弹窗
    alert("hahahhahahha");
  };

  // G、阻止事件冒泡 e.stopPropagation();

  // H、同步异步
  console.log(1);
  setTimeout(function () {
    console.log(3);
  }, 0);
  console.log(2);

  // 创建节点
  // const getNewnode = () => {
  //   var li = document.createElement('li');
  //   var ul = document.querySelector('ul');
  //   ul.appendChild(li);
  //   var lili = document.createElement('li');
  //   ul.insertBefore(lili, ul.children[0]);
  // }

  return (
    // <div>
    //   {/* 点击的时候触发事件-弹窗 */}
    //   <input id="test" type="button" value="提交" onClick={onLoad} />
    //   {/* DOM */}
    //   <div id="name" onClick={onClick}>
    //     新名字
    //   </div>
    //   <ul>
    //     <li>123</li>
    //   </ul>
    //   {/* I、模拟登录跳转 */}
    //   <form action="h.html">
    //     用户名：
    //     <input type="text" name="name" />
    //     <input type="submit" name="登录" />
    //   </form>
    // </div>
    <div>123</div>
  );
}
