import React, { Component } from 'react'

export default class NodePage extends Component {
    render() {
        return (
            <div>
                1212
            </div>
        )
    }
}
