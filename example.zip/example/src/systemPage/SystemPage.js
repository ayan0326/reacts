import React from "react";
import { useWeb3 } from "@openzeppelin/network/react";
import Web3Data from "./Web3Data";
// walletconnect
import WalletConnectClient from "@walletconnect/client";
import { CLIENT_EVENTS } from "@walletconnect/client";
import { PairingTypes } from "@walletconnect/types";
import Web3 from 'web3';
import WalletConnectProvider from "@walletconnect/web3-provider";

// 以太坊服务器INFURA
const infuraProjectId = "e91aef42552540328c17a58eaefea7cf"; // 项目ID，使用项目ID进行身份验证

// 项目ID，以太坊上创建新的项目，可以拿到项目ID和密钥，可以配置允许列表--访问允许列表
// 如果没有设置 AllowLists，所有请求都会被接受

export default function SystemPage() {
  // 创建web3实例去支持以太坊的浏览器小狐狸或者其他钱包
  const web3Context = useWeb3(
    // 网络配置 网络+项目ID   --- wss://mainnet.infura.io/ws/v3/项目ID
    `wss://mainnet.infura.io/ws/v3/${infuraProjectId}` // 与以太坊区块链的主要连接点，发送API请求的URL
  );

  // 二维码弹窗 获取钱包地址
  var web3 = new Web3(Web3.givenProvider || "ws://localhost:3000");
  async function Init(callback) {
    if (web3 != undefined) {
      const accounts = await web3.eth.getAccounts();
      callback(accounts[0]);
    }
  }

  // 连不上
  function _WalletContract(callback) {
    const provider = new WalletConnectProvider({
      rpc: {
        66: "https://exchainrpc.okex.org",
      },
      chainId: 66, //需要连接的区块链id
      networkId: 66,
      qrcode: true, //二维码是否开启
    });
    provider
      .enable()
      .then((res) => {
        web3 = new Web3(provider);

        //账户更改触发的方法
        provider.on("accountsChanged", (accounts) => {
          callback(accounts);
        });
        //账户断开的方法
        provider.on("disconnect", (code, reason) => {
          web3 = null;
          callback(code);
        });

        //这里返回的是链接地址
        Init((accounts) => {
          callback(accounts);
        });
      })
      .catch((err) => {
        callback("fail");
      });
  }

  return (
    <div className="App">
      <div>
        <h1 on>连接小狐狸hhhhh</h1>
        {/* 调用组件点击时连接小狐狸 */}
        <Web3Data title="Web3 Data" web3Context={web3Context}/>
      </div>
      <div>动画</div>
    </div>
  );
}
