import React, { useEffect } from "react";
import Web3 from "web3";
import Web3Modal from "web3modal";
import WalletConnectProvider from "@walletconnect/web3-provider";
// 提示
import Authereum from "authereum"; // Authereum 正在与应用开发工具套件 Abridged 合作，通过 Wyre 整合离线支付和法币出口。这将允许用户使用标准信用卡购买以太坊，并立即能够与 Layer 2 网络中的其他用户做价值互换而无需支付手续费
import Torus from "@toruslabs/torus-embed"; // yarn add @toruslabs/torus-embed  针对容器集群量身打造的存储系统
import Fortmatic from "fortmatic"; // npm i --save fortmatic@latest  允许将项目和以太坊区块链集成   https://docs.fortmatic.com/
import Portis from "@portis/web3"; // Portis 旨在确保世界上任何人都可以使用去中心化应用，像使用「常规」应用一样容易。他们制作简单的用户交互，鼓励 Portis 的每个人都充满好奇、大胆，激发最原始思维，其使命是使区块链尽可能地容易使用，完全改变你使用区块链应用的方式
import MewConnect from "@myetherwallet/mewconnect-web-client"; // 钱包MyEtherWallet推出用于iOS的MEWCONNECT移动应用程序,这是一款安全的移动应用程序，用于访问存储以太坊和erc-20代币的Mew帐户。
import { Bitski } from "bitski"; //

function App() {
  async function btnCall() {
    const providerOptions = {
      // 提供商配置
      walletconnect: {
        package: WalletConnectProvider, // required
        options: {
          infuraId: "INFURA_ID", // required
        },
      },

      torus: {
        package: Torus, // required
        options: {},
      },

      mewconnect: {
        package: MewConnect, // required
        options: {
          infuraId: "83d4d660ce3546299cbe048ed95b6fad", // required
        },
      },

      authereum: {
        package: Authereum, // required
      },

      bitski: {
        package: Bitski, // required
        options: {
          clientId: "BITSKI_CLIENT_ID", // required
          callbackUrl: "BITSKI_CALLBACK_URL", // required
        },
      },

      fortmatic: {
        package: Fortmatic, // required
        options: {
          key: "FORTMATIC_KEY", // required
        },
      },

      portis: {
        // const portis = new Portis('YOUR_DAPP_ID', 'mainnet'); 项目ID
        package: Portis, // required
        options: {
          id: "PORTIS_ID", // required
        },
      },
    };

    const web3Modal = new Web3Modal({
      // 弹窗默认主网
      network: "mainnet", // 主网optional
      cacheProvider: true, // 缓存optional
      providerOptions, // required 钱包项，如果不配置，使用web3modal默认打开小狐狸钱包
      theme: {
        // 弹窗主题
        background: "rgb(39, 49, 56)",
        main: "rgb(199, 199, 199)",
        secondary: "rgb(136, 136, 136)",
        border: "rgba(195, 195, 195, 0.14)",
        hover: "rgb(16, 26, 32)",
      },
    });

    const provider = await web3Modal.connect();

    const web3 = new Web3(provider);

    // 清除上一次的默认选项
    web3Modal.clearCachedProvider();

  }

  return (
    <div className="App">
      <div>
        <button className="button" onClick={btnCall}>
          Connect your wallet
        </button>
      </div>
    </div>
  );
}

export default App;
