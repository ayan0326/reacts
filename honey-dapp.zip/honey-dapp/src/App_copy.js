import React, { useState } from "react";
import { useWeb3 } from "@openzeppelin/network/react";
import Web3Data from "./wallet/Web3Data";
import { Modal, Button } from "antd";
// walletconnect
import WalletConnect from "@walletconnect/client";
import QRCodeModal from "@walletconnect/qrcode-modal";
// import { CLIENT_EVENTS } from "@walletconnect/client";
// import { PairingTypes } from "@walletconnect/types";
// import Web3 from 'web3';
// import WalletConnectProvider from "@walletconnect/web3-provider";

// 以太坊服务器INFURA
const infuraProjectId = "e91aef42552540328c17a58eaefea7cf"; // 项目ID，使用项目ID进行身份验证

// 项目ID，以太坊上创建新的项目，可以拿到项目ID和密钥，可以配置允许列表--访问允许列表
// 如果没有设置 AllowLists，所有请求都会被接受

export default function App() {
  // modal弹窗
  const [isModalVisible, setIsModalVisible] = useState(false);
  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  // 创建web3实例去支持以太坊的浏览器小狐狸或者其他钱包
  const web3Context = useWeb3(
    // 网络配置 网络+项目ID   --- wss://mainnet.infura.io/ws/v3/项目ID
    `wss://mainnet.infura.io/ws/v3/${infuraProjectId}` // 与以太坊区块链的主要连接点，发送API请求的URL
  );

  // walletconnect弹窗
  const connector = new WalletConnect({
    bridge: "https://bridge.walletconnect.org", // Required
    qrcodeModal: QRCodeModal,
  });

  // Check if connection is already established
  if (!connector.connected) {
    // create new session
    // connector.createSession();
  }

  // Subscribe to connection events
  connector.on("connect", (error, payload) => {
    if (error) {
      throw error;
    }

    // Get provided accounts and chainId
    const { accounts, chainId } = payload.params[0];
  });

  connector.on("session_update", (error, payload) => {
    if (error) {
      throw error;
    }

    // Get updated accounts and chainId
    const { accounts, chainId } = payload.params[0];
  });

  connector.on("disconnect", (error, payload) => {
    if (error) {
      throw error;
    }

    // Delete connector
  });

  return (
    <div className="App">
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          paddingLeft: "5%",
          paddingRight: "5%",
        }}
      >
        <h1 on>Honeybee House</h1>
        {/* 调用组件点击时连接小狐狸 */}
        {/* <Web3Data title="Web3 Data" web3Context={web3Context}/> */}
        {/* 点击connect先探出一个选项弹窗，然后点击哪个选项连接的就是哪个钱包 */}
        <>
          <Button type="primary" onClick={showModal}>
            Connect your wallet
          </Button>
          <Modal
            // title="Basic Modal"
            visible={isModalVisible}
            onOk={handleOk}
            onCancel={handleCancel}
          >
            <div style={{ display: "flex", alignItems: "center" }}>
              <Web3Data title="Web3 Data" web3Context={web3Context} />
              <p>Matamask</p>
            </div>
          </Modal>
        </>
      </div>
    </div>
  );
}
